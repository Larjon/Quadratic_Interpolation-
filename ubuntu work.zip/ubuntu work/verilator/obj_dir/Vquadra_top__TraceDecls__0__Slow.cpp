// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vquadra_top___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vquadra_top___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vquadra_top___024root__traceDeclTypesSub0(tracep);
}
