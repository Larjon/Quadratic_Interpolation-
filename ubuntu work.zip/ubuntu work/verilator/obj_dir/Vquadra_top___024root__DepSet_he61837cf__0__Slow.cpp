// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquadra_top.h for the primary calling header

#include "Vquadra_top__pch.h"
#include "Vquadra_top___024root.h"

VL_ATTR_COLD void Vquadra_top___024root___eval_static(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_static\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__clk__0 = vlSelfRef.clk;
}

VL_ATTR_COLD void Vquadra_top___024root___eval_initial(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_initial\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vquadra_top___024root___eval_final(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_final\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__stl(Vquadra_top___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vquadra_top___024root___eval_phase__stl(Vquadra_top___024root* vlSelf);

VL_ATTR_COLD void Vquadra_top___024root___eval_settle(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_settle\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY(((0x64U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vquadra_top___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("/home/kowal/intel/eda_tools/rtl-model/quadra_top.vs", 3, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vquadra_top___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__stl(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___dump_triggers__stl\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vquadra_top___024root___stl_sequent__TOP__0(Vquadra_top___024root* vlSelf);
VL_ATTR_COLD void Vquadra_top___024root____Vm_traceActivitySetAll(Vquadra_top___024root* vlSelf);

VL_ATTR_COLD void Vquadra_top___024root___eval_stl(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_stl\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        Vquadra_top___024root___stl_sequent__TOP__0(vlSelf);
        Vquadra_top___024root____Vm_traceActivitySetAll(vlSelf);
    }
}

VL_ATTR_COLD void Vquadra_top___024root___stl_sequent__TOP__0(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___stl_sequent__TOP__0\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_2;
    VlWide<3>/*95:0*/ __Vtemp_3;
    // Body
    vlSelfRef.y_dv = vlSelfRef.quadra_top__DOT__dv_p2;
    if (((((((((0U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
               | (1U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
              | (2U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
             | (3U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
            | (4U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
           | (5U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
          | (6U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
         | (7U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf4afb0cdU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x16a09e66U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x16a09e66U;
        } else if ((1U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf50b9983U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1752c7caU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x15e8ccf9U;
        } else if ((2U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf56a3f45U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x17ff1c9bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x152b8176U;
        } else if ((3U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf5cb8a69U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x18a571c5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x1468eb2fU;
        } else if ((4U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf62f629cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x19459db3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x13a13ac8U;
        } else if ((5U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf695aeeaU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x19df785bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x12d4a22dU;
        } else if ((6U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf6fe55bfU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1a72db48U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x12035482U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf7693cf3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1affa1a1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x112d861aU;
        }
    } else if (((((((((8U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (9U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0xaU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0xbU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0xcU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0xdU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0xeU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0xfU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((8U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf7d649ccU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1b85a836U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x10536c67U;
        } else if ((9U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf8456108U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1c04cd86U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf753defU;
        } else if ((0xaU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf8b666e2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1c7cf1c7U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe93323cU;
        } else if ((0xbU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf9293f18U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1cedf6f2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xdad81d1U;
        } else if ((0xcU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf99dccf5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1d57c0c6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xcc46616U;
        } else if ((0xdU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfa13f356U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1dba34d1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xbd81954U;
        } else if ((0xeU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfa8b94b3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1e153a76U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xae8d69bU;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfb049323U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1e68baf4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x9f6d9baU;
        }
    } else if (((((((((0x10U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x11U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x12U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x13U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x14U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x15U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x16U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x17U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x10U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfb7ed068U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1eb4a16dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x9025f31U;
        } else if ((0x11U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfbfa2df2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ef8dae6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x80ba41cU;
        } else if ((0x12U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfc768cecU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f355652U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x712e628U;
        } else if ((0x13U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfcf3ce3eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f6a0491U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x6186384U;
        } else if ((0x14U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfd71d298U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f96d87aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x51c5ad0U;
        } else if ((0x15U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfdf07a7aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fbbc6d6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x41f0b0cU;
        } else if ((0x16U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfe6fa63bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fd8c66bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x320b38aU;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfeef3610U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fedcff9U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x22193e0U;
        }
    } else if (((((((((0x18U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x19U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x1aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x1bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x1cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x1dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x1eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x1fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x18U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xff6f0a16U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ffade3dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x121ebd4U;
        } else if ((0x19U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xffef0259U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fffedf5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x21fb4eU;
        } else if ((0x1aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x6efedbU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ffcfddcU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xff220249U;
        } else if ((0x1bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xeedf9eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ff20eaeU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfe2240c3U;
        } else if ((0x1cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x16e84abU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fdf2326U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfd22f6aaU;
        } else if ((0x1dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x1edce18U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fc44001U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfc2463d0U;
        } else if ((0x1eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x26c9c14U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1fa16bf6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfb26c7d8U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x2eaceedU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f76afbaU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfa2a6227U;
        }
    } else if (((((((((0x20U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x21U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x22U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x23U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x24U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x25U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x26U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x27U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x20U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x3684715U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f4415fcU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf92f71d5U;
        } else if ((0x21U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x3e4e531U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1f09ab62U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf836359fU;
        } else if ((0x22U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x4608a18U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ec77e87U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf73eebd0U;
        } else if ((0x23U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x4db16e2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1e7d9ff5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf649d23bU;
        } else if ((0x24U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x5546ceeU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1e2c2224U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf5572624U;
        } else if ((0x25U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x5cc6de5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1dd31972U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf4672436U;
        } else if ((0x26U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x642fbc8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1d729c22U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf37a086fU;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x6b7f8f5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1d0ac253U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf2900e15U;
        }
    } else if (((((((((0x28U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x29U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x2aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x2bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x2cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x2dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x2eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x2fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x28U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x72b482dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1c9ba5f9U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf1a96fa6U;
        } else if ((0x29U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x79ccc9cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1c2562dcU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf0c666c8U;
        } else if ((0x2aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x80c69e2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1ba8168cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xefe72c3cU;
        } else if ((0x2bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x87a0419U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1b23e05bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xef0bf7cfU;
        } else if ((0x2cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x8e57fd9U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1a98e156U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xee35004eU;
        } else if ((0x2dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x94ec246U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1a073c3cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xed627b75U;
        } else if ((0x2eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x9b5b10eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x196f1576U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xec949de4U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xa1a3277U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x18d0930cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xebcb9b12U;
        }
    } else if (((((((((0x30U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x31U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x32U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x33U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x34U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x35U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x36U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x37U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x30U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xa7c2d61U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x182bdc9fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xeb07a53eU;
        } else if ((0x31U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xadb894eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x17811b5bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xea48ed65U;
        } else if ((0x32U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xb382e66U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x16d079efU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe98fa333U;
        } else if ((0x33U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xb920582U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x161a2484U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe8dbf4fbU;
        } else if ((0x34U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xbe8f82cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x155e48acU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe82e0fa7U;
        } else if ((0x35U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xc3cf0a8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x149d155fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe7861eafU;
        } else if ((0x36U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xc8dd9f8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x13d6bae8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe6e44c0fU;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xcdb9fe3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x130b6addU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe648c03aU;
        }
    } else if (((((((((0x38U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x39U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x3aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x3bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x3cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x3dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x3eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x3fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x38U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xd262ef6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x123b5811U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe5b3a213U;
        } else if ((0x39U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xd6d7490U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x1166b686U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe52516e1U;
        } else if ((0x3aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xdb15edeU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x108dbb66U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe49d4245U;
        } else if ((0x3bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xdf1dce6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfb09cecU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe41c4633U;
        } else if ((0x3cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe2ede8aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xecf9260U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe3a242ecU;
        } else if ((0x3dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe685489U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xdead404U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe32f56edU;
        } else if ((0x3eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe9e3087U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xd029b05U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe2c39ef2U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xed0650bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xc172170U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe25f35e9U;
        }
    } else if (((((((((0x40U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x41U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x42U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x43U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x44U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x45U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x46U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x47U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x40U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xefee58bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xb28a224U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe20234ebU;
        } else if ((0x41U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf29a664U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xa3758bdU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe1acb337U;
        } else if ((0x42U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf509ce9U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x943818eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe15ec62eU;
        } else if ((0x43U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf73bf5aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x84d598bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe118814bU;
        } else if ((0x44U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf9304f1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x7551e3dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0d9f61eU;
        } else if ((0x45U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfae65dbU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x65b0db1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0a3344bU;
        } else if ((0x46U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfc5db40U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x55f666aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0744980U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfd95f44U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x4626751U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe04d4179U;
        }
    } else if (((((((((0x48U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x49U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x4aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x4bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x4cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x4dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x4eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x4fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x48U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfe8ed04U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x3644fa3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe02e25f7U;
        } else if ((0x49U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xff4809fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x2655ee6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe016fec2U;
        } else if ((0x4aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xffc172fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x165d4d5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe007d1a2U;
        } else if ((0x4bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfffaecfU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0x65f150U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe000a263U;
        } else if ((0x4cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfff4698U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xff65f450U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe00172d1U;
        } else if ((0x4dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xffadea4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfe661dd1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe00a42b7U;
        } else if ((0x4eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xff2780fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfd66adcaU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe01b0fe2U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfe614f0U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfc67e413U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe033d61fU;
        }
    } else if (((((((((0x50U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x51U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x52U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x53U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x54U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x55U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x56U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x57U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x50U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfd5b862U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfb6a005eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0548f3cU;
        } else if ((0x51U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfc1667bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xfa6d4223U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe07d330bU;
        } else if ((0x52U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xfa9244fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf971e890U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0adb762U;
        } else if ((0x53U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf8cf7efU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf878327bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe0e61023U;
        } else if ((0x54U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf6ce865U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf7805e4eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe1262f36U;
        } else if ((0x55U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf48fdb6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf68aa9ffU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe16e0494U;
        } else if ((0x56U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xf2140dcU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf59752f8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe1bd7e48U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xef5bbc6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf4a6960fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe2148874U;
        }
    } else if (((((((((0x58U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x59U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x5aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x5bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x5cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x5dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x5eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x5fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x58U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xec67955U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf3b8af72U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe2730d56U;
        } else if ((0x59U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe938559U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf2cdda98U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe2d8f54dU;
        } else if ((0x5aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe5cec90U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf1e65236U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe34626e0U;
        } else if ((0x5bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xe22bc9eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf102502cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe3ba86c3U;
        } else if ((0x5cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xde50410U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xf0220d7bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe435f7dfU;
        } else if ((0x5dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xda3d254U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xef45c231U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe4b85b58U;
        } else if ((0x5eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xd5f37b5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xee6da560U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe5419095U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xd17455aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xed99ed0eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe5d1754bU;
        }
    } else if (((((((((0x60U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x61U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x62U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x63U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x64U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x65U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x66U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x67U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x60U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xccc0d40U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xeccace28U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe667e581U;
        } else if ((0x61U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xc7da233U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xec007c76U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe704bb9bU;
        } else if ((0x62U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xc2c17ceU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xeb3b2a89U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe7a7d065U;
        } else if ((0x63U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xbd78273U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xea7b09b7U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe850fb1aU;
        } else if ((0x64U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xb7ff748U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe9c04a05U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe9001171U;
        } else if ((0x65U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xb258c2eU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe90b1a23U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xe9b4e7a4U;
        } else if ((0x66U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xac857c0U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe85ba75cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xea6f5081U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xa68714aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe7b21d8bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xeb2f1d6cU;
        }
    } else if (((((((((0x68U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x69U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x6aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x6bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x6cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x6dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x6eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x6fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x68U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xa05f0c6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe70ea713U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xebf41e74U;
        } else if ((0x69U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x9a0eed3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe6716cd0U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xecbe225aU;
        } else if ((0x6aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x93984b1U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe5da960fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xed8cf69eU;
        } else if ((0x6bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x8cfcc3aU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe54a4886U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xee60678bU;
        } else if ((0x6cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x863dfdcU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe4c0a847U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xef384047U;
        } else if ((0x6dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x7f5da92U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe43dd7baU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf0144addU;
        } else if ((0x6eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x785d7dbU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe3c1f792U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf0f4504aU;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x713f3b8U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe34d26c6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf1d81890U;
        }
    } else if (((((((((0x70U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x71U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x72U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x73U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x74U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x75U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x76U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x77U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x70U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x6a04aa2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe2df828bU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf2bf6abcU;
        } else if ((0x71U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x62af982U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe2792648U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf3aa0cfcU;
        } else if ((0x72U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x5b41dacU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe21a2b94U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf497c4a9U;
        } else if ((0x73U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x53bd4d6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe1c2aa2dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf5885655U;
        } else if ((0x74U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x4c23d11U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe172b7f3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf67b85ddU;
        } else if ((0x75U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x44774c4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe12a68e3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf7711678U;
        } else if ((0x76U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x3cb9a9fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe0e9cf0fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf868cac1U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x34ecd99U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe0b0fa9fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xf96264ceU;
        }
    } else if (((((((((0x78U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))) 
                      | (0x79U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                     | (0x7aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                    | (0x7bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                   | (0x7cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                  | (0x7dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                 | (0x7eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) 
                | (0x7fU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U))))) {
        if ((0x78U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x2d12ce4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe07ff9c5U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfa5da638U;
        } else if ((0x79U == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x252d7e7U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe056d8c4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfb5a5031U;
        } else if ((0x7aU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x1d3ee38U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe035a1e2U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfc582391U;
        } else if ((0x7bU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x1548f8fU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe01c5d6dU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfd56e0e2U;
        } else if ((0x7cU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xd4dbc4U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe00b11b6U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xfe564878U;
        } else if ((0x7dU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0x54f2c3U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe001c310U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0xff561a79U;
        } else if ((0x7eU == (0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)))) {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xffd4f487U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe00073cfU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x5616f3U;
        } else {
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0xff55010cU;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0xe0072446U;
            vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0x155fde7U;
        }
    } else {
        vlSelfRef.quadra_top__DOT__u_quadra__DOT__a = 0U;
        vlSelfRef.quadra_top__DOT__u_quadra__DOT__b = 0U;
        vlSelfRef.quadra_top__DOT__u_quadra__DOT__c = 0U;
    }
    VL_WRITEF_NX("[LUT] index = %0d => a = 0x%x, b = 0x%x, c = 0x%x\n",0,
                 24,(0xffffffU & VL_SHIFTR_III(24,24,32, vlSelfRef.quadra_top__DOT__x_d0, 0x11U)),
                 32,vlSelfRef.quadra_top__DOT__u_quadra__DOT__a,
                 32,vlSelfRef.quadra_top__DOT__u_quadra__DOT__b,
                 32,vlSelfRef.quadra_top__DOT__u_quadra__DOT__c);
    vlSelfRef.quadra_top__DOT__u_quadra__DOT__b_mul_x 
        = VL_MULS_QQQ(64, VL_EXTENDS_QI(64,32, vlSelfRef.quadra_top__DOT__u_quadra__DOT__b), 
                      VL_EXTENDS_QI(64,24, vlSelfRef.quadra_top__DOT__x_d0));
    vlSelfRef.quadra_top__DOT__u_quadra__DOT__b_scaled 
        = VL_SHIFTRS_QQI(64,64,32, vlSelfRef.quadra_top__DOT__u_quadra__DOT__b_mul_x, 0x1cU);
    VL_EXTENDS_WI(96,32, __Vtemp_1, vlSelfRef.quadra_top__DOT__u_quadra__DOT__c);
    VL_EXTENDS_WQ(96,48, __Vtemp_2, (0xffffffffffffULL 
                                     & VL_MULS_QQQ(48, 
                                                   (0xffffffffffffULL 
                                                    & VL_EXTENDS_QI(48,24, vlSelfRef.quadra_top__DOT__x_d0)), 
                                                   (0xffffffffffffULL 
                                                    & VL_EXTENDS_QI(48,24, vlSelfRef.quadra_top__DOT__x_d0)))));
    VL_MULS_WWW(96, vlSelfRef.quadra_top__DOT__u_quadra__DOT__c_mul_sq, __Vtemp_1, __Vtemp_2);
    VL_SHIFTRS_WWI(96,96,32, __Vtemp_3, vlSelfRef.quadra_top__DOT__u_quadra__DOT__c_mul_sq, 0x33U);
    vlSelfRef.quadra_top__DOT__u_quadra__DOT__c_scaled 
        = (((QData)((IData)(__Vtemp_3[1U])) << 0x20U) 
           | (QData)((IData)(__Vtemp_3[0U])));
    vlSelfRef.quadra_top__DOT__u_quadra__DOT__a_ext 
        = VL_SHIFTR_QQI(64,64,32, (((QData)((IData)(
                                                    (- (IData)(
                                                               (vlSelfRef.quadra_top__DOT__u_quadra__DOT__a 
                                                                >> 0x1fU))))) 
                                    << 0x20U) | (QData)((IData)(vlSelfRef.quadra_top__DOT__u_quadra__DOT__a))), 5U);
    vlSelfRef.quadra_top__DOT__u_quadra__DOT__y_full 
        = ((vlSelfRef.quadra_top__DOT__u_quadra__DOT__a_ext 
            + vlSelfRef.quadra_top__DOT__u_quadra__DOT__b_scaled) 
           + vlSelfRef.quadra_top__DOT__u_quadra__DOT__c_scaled);
    vlSelfRef.y = (0xffffffU & (IData)(vlSelfRef.quadra_top__DOT__u_quadra__DOT__y_full));
}

VL_ATTR_COLD void Vquadra_top___024root___eval_triggers__stl(Vquadra_top___024root* vlSelf);

VL_ATTR_COLD bool Vquadra_top___024root___eval_phase__stl(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_phase__stl\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vquadra_top___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        Vquadra_top___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__act(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___dump_triggers__act\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clk)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__nba(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___dump_triggers__nba\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vquadra_top___024root____Vm_traceActivitySetAll(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root____Vm_traceActivitySetAll\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[0U] = 1U;
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
}

VL_ATTR_COLD void Vquadra_top___024root___ctor_var_reset(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___ctor_var_reset\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->rst_b = VL_RAND_RESET_I(1);
    vlSelf->x = VL_RAND_RESET_I(24);
    vlSelf->x_dv = VL_RAND_RESET_I(1);
    vlSelf->y = VL_RAND_RESET_I(24);
    vlSelf->y_dv = VL_RAND_RESET_I(1);
    vlSelf->quadra_top__DOT__dv_p0 = VL_RAND_RESET_I(1);
    vlSelf->quadra_top__DOT__dv_p1 = VL_RAND_RESET_I(1);
    vlSelf->quadra_top__DOT__dv_p2 = VL_RAND_RESET_I(1);
    vlSelf->quadra_top__DOT__x_d0 = VL_RAND_RESET_I(24);
    vlSelf->quadra_top__DOT__u_quadra__DOT__a = VL_RAND_RESET_I(32);
    vlSelf->quadra_top__DOT__u_quadra__DOT__b = VL_RAND_RESET_I(32);
    vlSelf->quadra_top__DOT__u_quadra__DOT__c = VL_RAND_RESET_I(32);
    vlSelf->quadra_top__DOT__u_quadra__DOT__b_mul_x = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(96, vlSelf->quadra_top__DOT__u_quadra__DOT__c_mul_sq);
    vlSelf->quadra_top__DOT__u_quadra__DOT__b_scaled = VL_RAND_RESET_Q(64);
    vlSelf->quadra_top__DOT__u_quadra__DOT__c_scaled = VL_RAND_RESET_Q(64);
    vlSelf->quadra_top__DOT__u_quadra__DOT__a_ext = VL_RAND_RESET_Q(64);
    vlSelf->quadra_top__DOT__u_quadra__DOT__y_full = VL_RAND_RESET_Q(64);
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}
